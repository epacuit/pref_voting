from pref_voting.scoring_methods import *
from pref_voting.iterative_methods import *
from pref_voting.mg_methods import *
from pref_voting.combined_methods import *
from pref_voting.other_methods import *
