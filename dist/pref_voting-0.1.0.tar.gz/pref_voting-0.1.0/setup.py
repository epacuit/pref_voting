# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pref_voting']

package_data = \
{'': ['*'], 'pref_voting': ['pref_voting.egg-info/*']}

install_requires = \
['matplotlib>=3.5.2,<4.0.0',
 'networkx>=2.8.5,<3.0.0',
 'numba>=0.56.0,<0.57.0',
 'numpy>=1.22.0,<2.0.0',
 'random2>=1.0.1,<2.0.0',
 'tabulate>=0.8.10,<0.9.0']

setup_kwargs = {
    'name': 'pref-voting',
    'version': '0.1.0',
    'description': 'Tools to study preferential voting methods',
    'long_description': None,
    'author': 'Eric Pacuit',
    'author_email': 'epacuit@umd.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
