'''
    File: generate_margin_graphs.py
    Author: Eric Pacuit (epacuit@umd.edu)
    Date: September 12, 2021
    
    Functions to generate a margin graph
    
'''


 